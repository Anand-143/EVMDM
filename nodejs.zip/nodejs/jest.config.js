module.exports = {
  testEnvironment: 'node',
};
