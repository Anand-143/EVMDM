const aws = require("aws-sdk");
const proxy = require('proxy-agent');
const httpProxy = process.env.http_proxy;
const httpsProxy = process.env.http_proxy;
const noProxy = (process.env.no_proxy) ? (process.env.no_proxy).split(",") : "";

aws.config.update({
  httpOptions: { agent: proxy(httpProxy,httpsProxy,...noProxy) }
});

async function send(from = "", to=[], subject = "", html = "", text = "") {
  const ses = new aws.SES({ region: "us-east-1" });
  const params = {
    Destination: {
      ToAddresses: to,
    },
    Message: {
      Body: {
        Text: { Data: text },
        Html: {
          Charset: "UTF-8",
          Data: html
        },
      },

      Subject: { Data: subject },
    },
    Source: from,
  };
  return ses.sendEmail(params).promise();
}



module.exports = { send };
