## **About**
Sending the email from EV-MDM

## **Description**
This layer uses the AWS SES. The AWS SES is hidden component for sending mails.

The NEE Support team is offered mail proxy to use sending mail, which is uses internally SES.

Mail Proxy is open required port numbers for sending email from SES.

## **Setup Environment Variable/ Required Variable** ##

**http_proxy** - which is provided by NEE Support team

**https_proxy** - which is provided by NEE Support team

**no_proxy** - which is provided by NEE Support team

## **Technical Details** ##

**http_proxy** - module used for make connection http proxies.


## **Common Commands**

Clone Repository: **git clone github_url**

Install Dependency for Development- **npm install**

Identify Code Standards(linters)- **npm run lint**

Fix Code Standards(es-7) - **npm run lint-fix**

Run Unit Test - **npm run test**

Build for Production : **npm install --env=prod**

## **Help**

Reach out ev-mdm developer
