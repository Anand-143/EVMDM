const assert = require('assert');
const sinon = require('sinon');


const {
  send,
} = require('./mail');

describe('mail', () => {
  describe('send', () => {
    beforeEach(() => {

    });

    afterEach(() => {
      sinon.restore();
    });

    it('should return true', async () => {

      assert.equal(true, true);
    });
  });
});
